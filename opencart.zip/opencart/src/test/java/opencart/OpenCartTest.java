package opencart;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OpenCartTest {

    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application");


        WebDriver driver = new ChromeDriver();


        driver.get("https://demo.opencart.com/");


        WebElement wishlistLink = driver.findElement(By.xpath("//a[@id='wishlist-total']"));
        wishlistLink.click();


        int numberOfSearchBoxes = driver.findElements(By.cssSelector("input[name='search']")).size();
        System.out.println("Number of search boxes: " + numberOfSearchBoxes);


        WebElement emailInputField = driver.findElement(By.id("input-email"));
        emailInputField.clear();
        emailInputField.sendKeys("email@email.com");


        driver.findElement(By.id("button-register")).click();


        WebElement passwordInputField = driver.findElement(By.id("input-password"));
        System.out.println("Is password input field enabled? " + passwordInputField.isEnabled());


        WebElement cartElement = driver.findElement(By.id("cart"));
        System.out.println("Is cart element displayed? " + cartElement.isDisplayed());


        WebElement agreeCheckbox = driver.findElement(By.name("agree"));
        System.out.println("Is agree checkbox selected? " + agreeCheckbox.isSelected());


        WebElement desktopsMenu = driver.findElement(By.xpath("//a[text()='Desktops']"));
        desktopsMenu.click();


        Select itemsPerPageDropdown = new Select(driver.findElement(By.id("input-limit")));
        itemsPerPageDropdown.selectByValue("25");


        WebElement selectedOption = itemsPerPageDropdown.getFirstSelectedOption();
        System.out.println("Selected option: " + selectedOption.getText());


        itemsPerPageDropdown.selectByIndex(3);


        selectedOption = itemsPerPageDropdown.getFirstSelectedOption();
        System.out.println("Selected option after changing: " + selectedOption.getText());

        
        driver.quit();
    }
}